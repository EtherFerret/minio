import os
import docker
from rgwadmin import RGWAdmin
import sys
if sys.version_info > (3,0):
    import urllib.parse as urlparse
else:
    import urlparse

def start_s3_service(admin_ak, admin_sk, ceph_rgw_url, uid):
    url = urlparse.urlparse(ceph_rgw_url)

    secure = False
    if url.scheme == 'https':
        secure = True

    rgw = RGWAdmin(access_key = admin_ak, secret_key = admin_sk, server = url.netloc, secure = secure)

    user = rgw.get_user(uid)
    if not user:
        return

    ak = ''
    sk = ''

    #docker_client = docker.DockerClient(base_url='unix://var/run/docker.sock')
    docker_client = docker.from_env()

    for key in user['keys']:
        ak = key.get('access_key')
        sk = key.get('secret_key')
        user = key.get('user')

        if not ak or not sk:
            continue

        image = 'ehualu.com/minio'
        #name = '%s.s3.datalake.com' % user
        name = 's3-%s' % user
        env = ['MINIO_ACCESS_KEY=%s' % ak, 'MINIO_SECRET_KEY=%s' % sk]
        args = ['gateway', 's3',  ceph_rgw_url]

        print(name)

        docker_client.services.create(
                image = image,
                name = name,
                env = env,
                networks = ['datalake'], 
                args = args)

def start_s3_services(admin_ak, admin_sk, ceph_rgw_url):
    url = urlparse.urlparse(ceph_rgw_url)

    secure = False
    if url.scheme == 'https':
        secure = True

    rgw = RGWAdmin(access_key = admin_ak, secret_key = admin_sk, server = url.netloc, secure = secure)
    for uid in rgw.get_users():
        # start up minio for this user
        try:
            print("Found user %s, trying to start s3 service" % uid)
            start_s3_service(admin_ak, admin_sk, ceph_rgw_url, uid)
        except Exception as e:
            print("Got exception %s while trying to start s3 service for %s" % (e, uid))

