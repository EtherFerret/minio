import bottle
from datetime import datetime
from bottle import request, response
import logging
import os
from adminlake import services
from bottle.ext.websocket import GeventWebSocketServer
from bottle.ext.websocket import websocket

logging_level = logging.DEBUG
logging_format = '%(asctime)s %(filename)s:%(lineno)d %(levelname)s %(message)s'

app = application = bottle.app()
logging.basicConfig(level=logging_level, format=logging_format)


@app.route('/v1/users/<username>', method=['PUT'])
def user_add(username):
    pass

@app.get('/v1/notification', apply=[websocket])
def notification(ws):
    pass

def main():
    import logging
    import sys
    import requestlogger

    loggedapp = requestlogger.WSGILogger(
        app,
        [logging.StreamHandler(stream=sys.stdout)],
        requestlogger.ApacheFormatter())

    # Env
    admin_ak = os.environ.get('ADMIN_AK')
    admin_sk = os.environ.get('ADMIN_SK')
    ceph_rgw_url = os.environ.get('CEPH_RGW_URL')

    if not admin_ak or not admin_sk or not ceph_rgw_url:
        print("Please check the environment ADMIN_AK, ADMIN_SK, CEPH_RGW_URL!")
        return

    # Start all services
    try:
        services.start_s3_services(admin_ak, admin_sk, ceph_rgw_url)
    except Exception as e:
        print("Got exception %s" % e)
        raise

    # Start the API server
    bottle.run(loggedapp, server='cherrypy', host='0.0.0.0', port=8080)

